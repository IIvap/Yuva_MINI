package com.hcl.prj.doa;
import java.util.*;

import com.hcl.prj.connection.DataConnect;

import java.sql.*;
public class UserDAO {
	private Scanner sc;
	private Connection con;
	private PreparedStatement stat;
	private ResultSet result;
	public UserDAO()
	{
		sc=new Scanner(System.in);
		con=DataConnect.getConnect();
		sc=new Scanner(System.in);
		
	}
	public void checkUser()
	{
		System.out.println("Enter user name ");
		String user=sc.next();
		System.out.println("Enter password");
		String pass=sc.next();
		try {
		stat=con.prepareStatement("select * from user where user_name=? and password=?");
		stat.setString(1, user);
		stat.setString(2, pass);
		ResultSet result=stat.executeQuery();
		if(result.next())
		{
			System.out.println("VAlid user");
			
		}
		else
		{
			System.out.println("invalid user");
		}
		}
		catch(SQLException ex)
		{
			System.out.println("Exception is "+ex.getMessage());
		}
		
	}
	public static void main(String[] args) {
		UserDAO userd=new UserDAO();
		userd.checkUser();
	}
}
