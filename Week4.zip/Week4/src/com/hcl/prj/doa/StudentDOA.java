package com.hcl.prj.doa;

import java.util.Scanner;
import java.sql.*;

import com.hcl.prj.connection.DataConnect;
import com.hcl.prj.dto.Student;

public class StudentDOA {
	private Student st;
	private Scanner sc;
	private Connection conn;
	private Statement stat;//This interface can be used to write any type of query in the databse.
	public StudentDOA()
	{
		st=new Student();
		sc=new Scanner(System.in);
		conn=DataConnect.getConnect();
		System.out.println("Connection established");
	}
	public void insert()
	{
		try
		{
		stat=conn.createStatement();//We want to create sttement in given connnection
		int x=stat.executeUpdate("insert into student values(3,'mira',21,1001)");
		if(x>0)
		{
			System.out.println("Data inserted successfully");
		}
		else
		{
			System.out.println("Not inserted ");
		}
		}
		catch(SQLException ex)
		{
			System.out.println("Exception is "+ex.getMessage());
		}
	}
	
	public void delete()
	{
		try
		{
			stat=conn.createStatement();
			int deletedata=stat.executeUpdate("delete from student where student_id=1");
			if(deletedata>0)
			{
				System.out.println("Data deleted successfully");
			}
		}
		catch(SQLException ex)
		{
			System.out.println("Exception is "+ex.getMessage());
		}
		
	}
	
	public void retreive()
	{
		try
		{
		stat=conn.createStatement();
		ResultSet result=stat.executeQuery("select * from student");
		while(result.next())
		{
			System.out.println("Student id is "+result.getInt(1));
			System.out.println("Student name is "+result.getString(2));
			
		}
		}
		catch(SQLException ex)
		{
			System.out.println("Exception is "+ex.getMessage());
		}
	}


	public static void main(String[] args) {
		StudentDOA studentobj=new StudentDOA();
		//studentobj.insert();
		//studentobj.delete();
		studentobj.retreive();
	}

}
