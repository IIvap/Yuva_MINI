package com.hcl.prj.doa;
import java.sql.*;
import java.util.*;

import com.hcl.prj.connection.DataConnect;
import com.hcl.prj.dto.Student;
public class StudentDAOFlexi {
	private Student student;
	private Connection con;
	private Scanner sc;
	private PreparedStatement stat;//PreparedStatment interface can be used to take input frmo user.
	public StudentDAOFlexi()
	{
		con=DataConnect.getConnect();
		student=new Student();
		sc=new Scanner(System.in);
	}
	public void insert()
	{
		System.out.println("Enter Student code");
		int studentcode=sc.nextInt();
		System.out.println("Enter Student name ");
		String name=sc.next();
		System.out.println("Enter Age");
		int age=sc.nextInt();
		System.out.println("Enter college code");
		int collegecode=sc.nextInt();
		try
		{
		stat=con.prepareStatement("insert into student values(?,?,?,?)");
		stat.setInt(1,studentcode);//in firstparameter i am passing value of studentcode
		stat.setString(2, name);
		stat.setInt(3, age);
		stat.setInt(4, collegecode);
		int x=stat.executeUpdate();
		if(x>0)
		{
			System.out.println("Data inerted");
		}
		}
		catch(SQLException ex)
		{
			System.out.println("Exception is "+ex.getMessage());
		}
		
	}
	public static void main(String[] args) {
		StudentDAOFlexi flexi=new StudentDAOFlexi();
		flexi.insert();
	}

}

