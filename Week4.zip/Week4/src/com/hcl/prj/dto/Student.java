package com.hcl.prj.dto;

public class Student {
	private int studenti_id;
	private String student_name;
	private int age;
	private int college_code;
	public int getStudenti_id() {
		return studenti_id;
	}
	public void setStudenti_id(int studenti_id) {
		this.studenti_id = studenti_id;
	}
	public String getStudent_name() {
		return student_name;
	}
	public void setStudent_name(String student_name) {
		this.student_name = student_name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getCollege_code() {
		return college_code;
	}
	public void setCollege_code(int college_code) {
		this.college_code = college_code;
	}

}
