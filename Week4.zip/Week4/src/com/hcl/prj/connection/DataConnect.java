package com.hcl.prj.connection;
import java.sql.*;
public class DataConnect {
	private static Connection con;//Connection interface can be used to store datbase connection

	private DataConnect()
	{
		/*
		 * jdbc protocl
		 * mysql=sub protocol
		 * localhost-address of machine where mysql installed
		 * 3306-port
		 * ems_hc-name of database.
		 * 
		 * root-username
		 * mysql-password of mysql
		 */
		try
		{
		Class.forName("com.mysql.jdbc.Driver");//It is dynmaically loading Driver class from com.mysql.jdbc package
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/travel	","root","root");
		}
		catch(ClassNotFoundException ex)
		{
			System.out.println("Unable to load drvier");
		}
		catch(SQLException ex)
		{
			System.out.println("exception is "+ex.getMessage());
		}
	}
	public static Connection getConnect()
	{
		DataConnect d=new DataConnect();
		return con;
	}
}
